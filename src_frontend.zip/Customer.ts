import { User } from "User";
export class Customer
{
   customerid: Number;
	
	accno: Number;
	acctype: String;
	accbal: Number;
	password: String;
     user = Object.assign({}, User);
}