export class AdminLogin{
    adminId : number;
    password : string;
}