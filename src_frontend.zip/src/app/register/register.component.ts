import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { User } from 'User';
import { UserRegisterService } from '../user-register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  form!: FormGroup;
  user: User = new User();
  route: any;
  
  constructor(private userRegisterService:UserRegisterService,private router : Router,private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      title:[, Validators.required],
      firstname:[, Validators.required],
      middlename:[,],
      lastname:[, Validators.required],
      fathername:[,Validators.required],
      mobilenumber: [, [Validators.required,  Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      email: [, [Validators.required, Validators.email]],
      aadhar: [, [Validators.required, Validators.pattern("^[0-9]{12}$")]],
      date: [, Validators.required],
      resaddrlane1: [, Validators.required],
      resaddrlane2: [,],
      reslandmark: [,],
      rescity: [, Validators.required],
      resstate: [, Validators.required],
      respincode: [, Validators.required],
      peraddrlane1: [, Validators.required],
      peraddrlane2: [, Validators.required],
      perlandmark: [,],
      percity: [, Validators.required],
      perstate: [, Validators.required],
      perpincode: [, Validators.required],
      occutype: [, Validators.required],
      incsource: [, Validators.required],
      annincome: [, Validators.required],
      netbanking:[,],
      status:[,]
   
    });
    
  }
  get registerFormControl() {
    return this.form.controls;
  }
  registerUser(){
    this.saveUser();
  }

  saveUser(){
    if (this.form.valid) { 
    this.user.status="Pending"; 
    this.user.netbanking=false;
    this.userRegisterService.createUser(this.user).subscribe(data=>{
      this.router.navigate(['thank-you-register']);
    })
  }
  else{
    alert("please fill all the required details!")
  }
  }
  updateAddress(event: any){
    // console.log(event.value)
    if(event.target.checked){
    this.user.peraddrlane1 = this.user.resaddrlane1
    this.user.peraddrlane2 = this.user.resaddrlane2
    this.user.perlandmark = this.user.reslandmark
    this.user.perstate = this.user.resstate
    this.user.percity = this.user.rescity
    this.user.perpincode = this.user.respincode
    }
    else{
    this.user.peraddrlane1 = ""
    this.user.peraddrlane2 = ""
    this.user.perlandmark = ""
    this.user.perstate = ""
    this.user.percity = ""
    this.user.perpincode = ""
    }
  }
}