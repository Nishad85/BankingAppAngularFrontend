import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deposit-money',
  templateUrl: './deposit-money.component.html',
  styleUrls: ['./deposit-money.component.css']
})
export class DepositMoneyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
