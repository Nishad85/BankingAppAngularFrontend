import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'User';
import { Transaction } from 'Transaction';
import { TransactionService } from '../transaction.service';

@Component({
  selector: 'app-rtgs-banking',
  templateUrl: './rtgs-banking.component.html',
  styleUrls: ['./rtgs-banking.component.css']
})
export class RtgsBankingComponent implements OnInit {
  rtgs: Transaction = new Transaction();
  route:any;
  customeridsessionstorage = sessionStorage.getItem('customerid')
  constructor(private TransactionService: TransactionService, private router :Router) { }

  ngOnInit(): void {
  }

  rtgsContinue(){
    
    this.rtgs.remarks="Sucessful";
   
    this.TransactionService.addTransactionRTGS(this.rtgs,this.customeridsessionstorage).subscribe(data=>{
    this.router.navigate(['transaction-status']);
   
  })
  

}
}