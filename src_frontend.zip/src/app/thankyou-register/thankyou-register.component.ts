import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thankyou-register',
  templateUrl: './thankyou-register.component.html',
  styleUrls: ['./thankyou-register.component.css']
})
export class ThankyouRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
