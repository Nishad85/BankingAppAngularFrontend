import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from 'User';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private create_cust_url="http://localhost:8088/BankingApp/createcustomer";
  private view_users="http://localhost:8088/BankingApp/admindashboard";
  private view_pending_users ="http://localhost:8088/BankingApp/admindashboard/pending";
  private change_net_bank_url="http://localhost:8088/BankingApp/changenetbanking/";
  constructor(private http_ser:HttpClient) { }

  createCustomer(user:User, userid:number): Observable<Object>{
    return this.http_ser.post(this.create_cust_url+'/'+userid,user);
  }

  getUserList(): Observable<User[]>{
    return this.http_ser.get<User[]>(this.view_users);   
  }

  getPendingUserList():Observable<User[]>{
    return this.http_ser.get<User[]>(this.view_pending_users);
  }
  setNetBank(user:User, userid:number) :Observable<Object>{
    return this.http_ser.put(this.change_net_bank_url+userid,User);
  }

}