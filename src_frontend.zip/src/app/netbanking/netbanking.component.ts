import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-netbanking',
  templateUrl: './netbanking.component.html',
  styleUrls: ['./netbanking.component.css']
})
export class NetbankingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
