import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-id',
  templateUrl: './forgot-id.component.html',
  styleUrls: ['./forgot-id.component.css']
})
export class ForgotIdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
